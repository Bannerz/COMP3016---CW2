// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
//  * Redistributions of source code must retain the above copyright
//    notice, this list of conditions and the following disclaimer.
//  * Redistributions in binary form must reproduce the above copyright
//    notice, this list of conditions and the following disclaimer in the
//    documentation and/or other materials provided with the distribution.
//  * Neither the name of NVIDIA CORPORATION nor the names of its
//    contributors may be used to endorse or promote products derived
//    from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS ''AS IS'' AND ANY
// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
// CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
// EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
// PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
// OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
// Copyright (c) 2008-2024 NVIDIA Corporation. All rights reserved.

#ifndef NV_NSFOUNDATION_NSINLINEARRAY_H
#define NV_NSFOUNDATION_NSINLINEARRAY_H

#include "NsArray.h"
#include "NsInlineAllocator.h"

namespace nvidia
{
namespace shdfnd
{

// array that pre-allocates for N elements
template <typename T, uint32_t N, typename Alloc = typename AllocatorTraits<T>::Type>
class InlineArray : public Array<T, InlineAllocator<N * sizeof(T), Alloc> >
{
    typedef InlineAllocator<N * sizeof(T), Alloc> Allocator;

  public:
    InlineArray(const NvEMPTY v) : Array<T, Allocator>(v)
    {
        if(isInlined())
            this->mData = reinterpret_cast<T*>(Array<T, Allocator>::getInlineBuffer());
    }

    NV_INLINE bool isInlined() const
    {
        return Allocator::isBufferUsed();
    }

    NV_INLINE explicit InlineArray(const Alloc& alloc = Alloc()) : Array<T, Allocator>(alloc)
    {
        this->mData = this->allocate(N);
        this->mCapacity = N;
    }
};
} // namespace shdfnd
} // namespace nvidia

#endif // #ifndef NV_NSFOUNDATION_NSINLINEARRAY_H
