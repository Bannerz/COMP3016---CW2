#!/bin/bash
SCRIPT_DIR=$(dirname ${BASH_SOURCE})

./external/premake/linux-aarch64/premake5 gmake2 --file="$SCRIPT_DIR/premake5.lua" || error_exit "Error while generating projects with premake"
